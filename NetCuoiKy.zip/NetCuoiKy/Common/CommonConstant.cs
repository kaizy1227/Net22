﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NetCuoiKy.Common
{
    public static class CommonConstant
    {
        public static  string USER_SESSION = "USER_SESSION";
    }
}